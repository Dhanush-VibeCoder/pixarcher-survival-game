gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDPlayerObjects1= [];
gdjs.Game_32SceneCode.GDPlayerObjects2= [];
gdjs.Game_32SceneCode.GDMoveJoystickObjects1= [];
gdjs.Game_32SceneCode.GDMoveJoystickObjects2= [];
gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects1= [];
gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects2= [];
gdjs.Game_32SceneCode.GDEnemyObjects1= [];
gdjs.Game_32SceneCode.GDEnemyObjects2= [];
gdjs.Game_32SceneCode.GDPlayerBulletObjects1= [];
gdjs.Game_32SceneCode.GDPlayerBulletObjects2= [];
gdjs.Game_32SceneCode.GDDebrisParticleObjects1= [];
gdjs.Game_32SceneCode.GDDebrisParticleObjects2= [];
gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects1= [];
gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects2= [];
gdjs.Game_32SceneCode.GDFantasyMonsterAssetTempObjects1= [];
gdjs.Game_32SceneCode.GDFantasyMonsterAssetTempObjects2= [];
gdjs.Game_32SceneCode.GDArrowAssetTempObjects1= [];
gdjs.Game_32SceneCode.GDArrowAssetTempObjects2= [];
gdjs.Game_32SceneCode.GDWaveTextObjects1= [];
gdjs.Game_32SceneCode.GDWaveTextObjects2= [];
gdjs.Game_32SceneCode.GDScoreTextObjects1= [];
gdjs.Game_32SceneCode.GDScoreTextObjects2= [];
gdjs.Game_32SceneCode.GDHealthBarObjects1= [];
gdjs.Game_32SceneCode.GDHealthBarObjects2= [];
gdjs.Game_32SceneCode.GDUpgradeTitleObjects1= [];
gdjs.Game_32SceneCode.GDUpgradeTitleObjects2= [];
gdjs.Game_32SceneCode.GDUpgradeButton1Objects1= [];
gdjs.Game_32SceneCode.GDUpgradeButton1Objects2= [];
gdjs.Game_32SceneCode.GDUpgradeButton2Objects1= [];
gdjs.Game_32SceneCode.GDUpgradeButton2Objects2= [];
gdjs.Game_32SceneCode.GDUpgradeButton3Objects1= [];
gdjs.Game_32SceneCode.GDUpgradeButton3Objects2= [];
gdjs.Game_32SceneCode.GDUpgradeButton4Objects1= [];
gdjs.Game_32SceneCode.GDUpgradeButton4Objects2= [];
gdjs.Game_32SceneCode.GDGameOverTextObjects1= [];
gdjs.Game_32SceneCode.GDGameOverTextObjects2= [];
gdjs.Game_32SceneCode.GDRestartButtonObjects1= [];
gdjs.Game_32SceneCode.GDRestartButtonObjects2= [];


gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Game_32SceneCode.GDEnemyObjects1});
gdjs.Game_32SceneCode.mapOfEmptyGDEnemyObjects = Hashtable.newFrom({"Enemy": []});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Game_32SceneCode.GDEnemyObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Game_32SceneCode.GDEnemyObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.Game_32SceneCode.GDPlayerBulletObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.Game_32SceneCode.GDPlayerBulletObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Game_32SceneCode.GDEnemyObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.Game_32SceneCode.GDDebrisParticleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDLargeDebrisParticleObjects1Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Game_32SceneCode.GDEnemyObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDLargeDebrisParticleObjects1Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects1});
gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(5);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("playing");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PlayerHit");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("RepeatingBackground"), gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects1[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects1[i].setYOffset(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EnemySpawn") >= 0.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "playing");
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.Game_32SceneCode.GDEnemyObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2), (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2), "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(0)).setNumber(2 + runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}
{runtimeScene.getScene().getVariables().getFromIndex(2).sub(1);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "playing");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].addForceTowardObject((gdjs.Game_32SceneCode.GDPlayerObjects1.length !== 0 ? gdjs.Game_32SceneCode.GDPlayerObjects1[0] : null), 100, 0);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.Game_32SceneCode.mapOfEmptyGDEnemyObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "playing");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15778468);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton1"), gdjs.Game_32SceneCode.GDUpgradeButton1Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton2"), gdjs.Game_32SceneCode.GDUpgradeButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton3"), gdjs.Game_32SceneCode.GDUpgradeButton3Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton4"), gdjs.Game_32SceneCode.GDUpgradeButton4Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeTitle"), gdjs.Game_32SceneCode.GDUpgradeTitleObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("betweenWaves");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeTitleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeTitleObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton1Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton1Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton2Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton2Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton3Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton3Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton4Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton4Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, 500, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getCenterYInScene()), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "playing");
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
gdjs.Game_32SceneCode.GDPlayerBulletObjects1.length = 0;

{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Game_32SceneCode.GDPlayerObjects1[i].getCenterXInScene()), (gdjs.Game_32SceneCode.GDPlayerObjects1[i].getCenterYInScene()), gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerBulletObjects1Objects, (( gdjs.Game_32SceneCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects1[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects1[0].getCenterYInScene()), 300, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("FireBullet").HasJustFired(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayerObjects1[k] = gdjs.Game_32SceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/starting_bulletfire.wav", false, 20, gdjs.randomWithStep(0.9, 1.2, 0.05));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.Game_32SceneCode.GDPlayerBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerBulletObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDPlayerBulletObjects1 */
gdjs.Game_32SceneCode.GDDebrisParticleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDebrisParticleObjects1Objects, (( gdjs.Game_32SceneCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, 30, gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerBulletObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects1[k] = gdjs.Game_32SceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects1 */
gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDLargeDebrisParticleObjects1Objects, (( gdjs.Game_32SceneCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects1[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects1[0].getCenterYInScene()), "");
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "PlayerHit") >= 0.5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects1.length = 0;

{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDLargeDebrisParticleObjects1Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, 90, gdjs.randomFloatInRange(0.7, 0.9));
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("Health").Hit(10, true, true, null);
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PlayerHit");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("WaveText"), gdjs.Game_32SceneCode.GDWaveTextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDWaveTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDWaveTextObjects1[i].getBehavior("Text").setText("Wave " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("Health").IsDead(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayerObjects1[k] = gdjs.Game_32SceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11871756);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GameOverText"), gdjs.Game_32SceneCode.GDGameOverTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("RestartButton"), gdjs.Game_32SceneCode.GDRestartButtonObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("gameover");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGameOverTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGameOverTextObjects1[i].getBehavior("Text").setText("Game Over" + gdjs.evtTools.string.newLine() + "Score: " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()) + gdjs.evtTools.string.newLine() + "Wave: " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGameOverTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGameOverTextObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDRestartButtonObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.Game_32SceneCode.GDHealthBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.Game_32SceneCode.GDScoreTextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDScoreTextObjects1[i].getBehavior("Text").setText("Score: " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDHealthBarObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDHealthBarObjects1[i].SetValue((( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getBehavior("Health").Health(null)), null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeButton1"), gdjs.Game_32SceneCode.GDUpgradeButton1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDUpgradeButton1Objects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDUpgradeButton1Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDUpgradeButton1Objects1[k] = gdjs.Game_32SceneCode.GDUpgradeButton1Objects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDUpgradeButton1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "betweenWaves");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15112924);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
/* Reuse gdjs.Game_32SceneCode.GDUpgradeButton1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton2"), gdjs.Game_32SceneCode.GDUpgradeButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton3"), gdjs.Game_32SceneCode.GDUpgradeButton3Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton4"), gdjs.Game_32SceneCode.GDUpgradeButton4Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeTitle"), gdjs.Game_32SceneCode.GDUpgradeTitleObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("FireBullet").SetCooldownOp(gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("FireBullet").Cooldown(null) * (0.85), null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeTitleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeTitleObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton1Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton1Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton2Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton3Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton3Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton4Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton4Objects1[i].hide();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("playing");
}
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(5 + (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() - 1) * 3);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeButton2"), gdjs.Game_32SceneCode.GDUpgradeButton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDUpgradeButton2Objects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDUpgradeButton2Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDUpgradeButton2Objects1[k] = gdjs.Game_32SceneCode.GDUpgradeButton2Objects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDUpgradeButton2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "betweenWaves");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12678100);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton1"), gdjs.Game_32SceneCode.GDUpgradeButton1Objects1);
/* Reuse gdjs.Game_32SceneCode.GDUpgradeButton2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton3"), gdjs.Game_32SceneCode.GDUpgradeButton3Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton4"), gdjs.Game_32SceneCode.GDUpgradeButton4Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeTitle"), gdjs.Game_32SceneCode.GDUpgradeTitleObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("FireBullet").SetBulletQuantityOp(gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("FireBullet").BulletQuantity(null) + (1), null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeTitleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeTitleObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton1Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton1Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton2Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton3Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton3Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton4Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton4Objects1[i].hide();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("playing");
}
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(5 + (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() - 1) * 3);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeButton3"), gdjs.Game_32SceneCode.GDUpgradeButton3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDUpgradeButton3Objects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDUpgradeButton3Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDUpgradeButton3Objects1[k] = gdjs.Game_32SceneCode.GDUpgradeButton3Objects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDUpgradeButton3Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "betweenWaves");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17686324);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton1"), gdjs.Game_32SceneCode.GDUpgradeButton1Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton2"), gdjs.Game_32SceneCode.GDUpgradeButton2Objects1);
/* Reuse gdjs.Game_32SceneCode.GDUpgradeButton3Objects1 */
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton4"), gdjs.Game_32SceneCode.GDUpgradeButton4Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeTitle"), gdjs.Game_32SceneCode.GDUpgradeTitleObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("Health").SetMaxHealthOp(gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("Health").MaxHealth(null) + (25), null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("Health").Heal(25, null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeTitleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeTitleObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton1Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton1Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton2Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton3Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton3Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton4Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton4Objects1[i].hide();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("playing");
}
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(5 + (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() - 1) * 3);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeButton4"), gdjs.Game_32SceneCode.GDUpgradeButton4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDUpgradeButton4Objects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDUpgradeButton4Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDUpgradeButton4Objects1[k] = gdjs.Game_32SceneCode.GDUpgradeButton4Objects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDUpgradeButton4Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "betweenWaves");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13461932);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton1"), gdjs.Game_32SceneCode.GDUpgradeButton1Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton2"), gdjs.Game_32SceneCode.GDUpgradeButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("UpgradeButton3"), gdjs.Game_32SceneCode.GDUpgradeButton3Objects1);
/* Reuse gdjs.Game_32SceneCode.GDUpgradeButton4Objects1 */
gdjs.copyArray(runtimeScene.getObjects("UpgradeTitle"), gdjs.Game_32SceneCode.GDUpgradeTitleObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").setMaxSpeed(gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").getMaxSpeed() + (30));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeTitleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeTitleObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton1Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton1Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton2Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton3Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton3Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDUpgradeButton4Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDUpgradeButton4Objects1[i].hide();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("playing");
}
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(5 + (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() - 1) * 3);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("RestartButton"), gdjs.Game_32SceneCode.GDRestartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDRestartButtonObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDRestartButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDRestartButtonObjects1[k] = gdjs.Game_32SceneCode.GDRestartButtonObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDRestartButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "gameover");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11749596);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDMoveJoystickObjects1.length = 0;
gdjs.Game_32SceneCode.GDMoveJoystickObjects2.length = 0;
gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects1.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerBulletObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerBulletObjects2.length = 0;
gdjs.Game_32SceneCode.GDDebrisParticleObjects1.length = 0;
gdjs.Game_32SceneCode.GDDebrisParticleObjects2.length = 0;
gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects1.length = 0;
gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects2.length = 0;
gdjs.Game_32SceneCode.GDFantasyMonsterAssetTempObjects1.length = 0;
gdjs.Game_32SceneCode.GDFantasyMonsterAssetTempObjects2.length = 0;
gdjs.Game_32SceneCode.GDArrowAssetTempObjects1.length = 0;
gdjs.Game_32SceneCode.GDArrowAssetTempObjects2.length = 0;
gdjs.Game_32SceneCode.GDWaveTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDWaveTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDScoreTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDScoreTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDHealthBarObjects1.length = 0;
gdjs.Game_32SceneCode.GDHealthBarObjects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeTitleObjects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeTitleObjects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton1Objects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton1Objects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton2Objects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton2Objects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton3Objects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton3Objects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton4Objects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton4Objects2.length = 0;
gdjs.Game_32SceneCode.GDGameOverTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDGameOverTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDRestartButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDRestartButtonObjects2.length = 0;

gdjs.Game_32SceneCode.eventsList0(runtimeScene);
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDMoveJoystickObjects1.length = 0;
gdjs.Game_32SceneCode.GDMoveJoystickObjects2.length = 0;
gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDRepeatingBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects1.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerBulletObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerBulletObjects2.length = 0;
gdjs.Game_32SceneCode.GDDebrisParticleObjects1.length = 0;
gdjs.Game_32SceneCode.GDDebrisParticleObjects2.length = 0;
gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects1.length = 0;
gdjs.Game_32SceneCode.GDLargeDebrisParticleObjects2.length = 0;
gdjs.Game_32SceneCode.GDFantasyMonsterAssetTempObjects1.length = 0;
gdjs.Game_32SceneCode.GDFantasyMonsterAssetTempObjects2.length = 0;
gdjs.Game_32SceneCode.GDArrowAssetTempObjects1.length = 0;
gdjs.Game_32SceneCode.GDArrowAssetTempObjects2.length = 0;
gdjs.Game_32SceneCode.GDWaveTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDWaveTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDScoreTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDScoreTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDHealthBarObjects1.length = 0;
gdjs.Game_32SceneCode.GDHealthBarObjects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeTitleObjects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeTitleObjects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton1Objects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton1Objects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton2Objects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton2Objects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton3Objects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton3Objects2.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton4Objects1.length = 0;
gdjs.Game_32SceneCode.GDUpgradeButton4Objects2.length = 0;
gdjs.Game_32SceneCode.GDGameOverTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDGameOverTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDRestartButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDRestartButtonObjects2.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
